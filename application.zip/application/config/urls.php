<?php

// base_url http://rechargeapp.test/

//  Site Settings 
$config['css'] = base_url().'assets/css/styles.css';
$config['stylecss'] = base_url().'assets/css/style.css';
$config['js'] = base_url().'assets/js/';
$config['image'] = base_url().'assets/img/';


// Login Controller
$config['login'] = base_url().'login/';
$config['login_check'] = base_url().'login/login_check/';

// home Controller
$config['home'] = base_url();   // Done

// listing Controller
$config['list'] = base_url().'list_mod/listing';    // Done
$config['inreq'] = base_url().'list_mod/listing/insert'; 

// wallet Controller
$config['wallet'] = base_url().'wallet/recharge';  

// recharge Controller
$config['recharge'] = base_url().'recharge_mod/recharge';  // Done
$config['buyplan'] = base_url().'recharge_mod/recharge/buyplan';

// Posttable
$config['posttable'] = base_url().'postreq_mod/post_table'; 
$config['delreq'] = base_url().'admin/postreq_mod/Post_table/delete/';
$config['updatereq'] = base_url().'admin/postreq_mod/Post_table/update/';
$config['updateinreq'] = base_url().'admin/postreq_mod/Post_table/updateinsert/';


// recharge Controller
$config['wallet'] = base_url().'wallet/recharge';   // Done


//image url
$config['image'] = base_url().'assets/img/';


//Referand earn
$config['referandearn'] = base_url().'referandearn_mod/referandearn';

























// Post Req Controller
// $config['post_req'] = base_url().'admin/postreq_mod/Post_req';
// $config['inreq'] = base_url().'admin/postreq_mod/Post_req/insert';
// $config['delreq'] = base_url().'admin/postreq_mod/Post_req/delete/';
// $config['updatereq'] = base_url().'admin/postreq_mod/Post_req/update';

// Post Req Controller

// $config['test'] = base_url().'admin/postreq_mod/Post_req/demo';

// $config['post_req'] = base_url().'admin/postreq_mod/Post_req';
// $config['inreq'] = base_url().'admin/postreq_mod/Post_req/insert';
// $config['getreq'] = base_url().'admin/postreq_mod/Post_req/get';
// $config['delreq'] = base_url().'admin/postreq_mod/Post_req/delete/';
// $config['updatereq'] = base_url().'admin/postreq_mod/Post_req/update/';
// $config['updateinreq'] = base_url().'admin/postreq_mod/Post_req/updateinsert/';

// Posttable Controller
// $config['post_list'] = base_url().'admin/postreq_mod/Post_list/index.';

// recharge Controller
// $config['recharge'] = base_url().'admin/wallet/Recharge/index.';

// refferal Controller
// $config['refferal'] = base_url().'admin/wallet/Refferal/index.';

// field Controller
// $config['field'] = base_url().'admin/wallet/Field/index.';
// payment Controller
// $config['payment'] = base_url().'admin/payment_mod/Payment/index.';

// Register
// $config['register'] = base_url().'register/';