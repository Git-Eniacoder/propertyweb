<?php

$config['insert'] = base_url().'login/';
                    