<?php

class Test extends My_Controller {

    public function index()
    {
        // echo "hi";
         echo "<pre>";
        print_r($this->data);
        die;
    }

}

/* End of file Controllername.php */