<!-- Refer and earn -->
<!-- Recharge Section -->

<div class="recharge-main">
    <div class="container">
        <div class="row">
            <div class="col-md-8 ">
                <div class="form-head">
                    <h3>Refer And Earn</h3>
                    <hr class="style1">
                </div>
                <div class="plans">
                    <!-- <h6></h6> -->

                    <div>
                        <p> Lorem ipsum, dolor sit amet consectetur adipisicing elit. </p>
                    </div>


                </div>
            </div>
            <div class="col-md-4 rgt">
                <div class="card">
                    <h6>How we solve your problem</h6>
                    <p>Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
                <div class="card">
                    <h6>How we solve your problem</h6>
                    <p>Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- end Of recharge -->